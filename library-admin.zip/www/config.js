window.CONFIG = { API_BASE: "https://amir00l.pythonanywhere.com/lib" };
